﻿using CommunityWebsite.Controllers;
using CommunityWebsite.Models;
using CommunityWebsite.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace CommunityWebsite.Tests
{
    public class MembersTests
    {
        [Fact]
        public void CanGetAllMembersRegisteredOnDate()
        {
            
        }

        [Fact]
        public void CanGetMemberByName()
        {
            
        }
    }
}
